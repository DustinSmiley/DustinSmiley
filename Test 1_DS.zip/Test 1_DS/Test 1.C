// ------------------------------------------------------------------------------------------
// Name: Dustin Smiley
// Class: C Programming
// Abstract: Test 1
// ------------------------------------------------------------------------------------------

// ------------------------------------------------------------------------------------------
// Includes
// ------------------------------------------------------------------------------------------
#include<stdio.h>
#include<stdlib.h>

// ------------------------------------------------------------------------------------------
// Constants
// ------------------------------------------------------------------------------------------

// ------------------------------------------------------------------------------------------
// Prototypes
// ------------------------------------------------------------------------------------------
int GetYearsEmployed();

float GetPreviousPurchasesBeforeDiscount();

char GetEmployeeStatus();

float GetTodaysTotalPurchases();

float GetManagmentDiscountPercentage(int intYearsEmployed);

float GetManagmentYearToDateDiscount(float sngManagmentDiscountPercentage, float sngPreviousPurchasesBeforeDiscount);

float GetManagmentDiscountThisPurchase(float sngTodaysTotalPurchases, float sngManagmentDiscountPercentage);

float GetManagmentTotalWithDiscount(float sngTodaysTotalPurchases, float sngManagmentDiscountPercentage);

float GetHourlyDiscountPercentage(int intYearsEmployed);

float GetHourlyYearToDateDiscount(float sngHourlyDiscountPercentage, float sngPreviousPurchasesBeforeDiscount);

float GetHourlyDiscountThisPurchase(float sngTodaysTotalPurchases, float sngHourlyDiscountPercentage);

float PrintManagmentDiscountPercentage(float sngManagmentDiscountPercentage);

float PrintManagmentYTDDiscount(float sngManagmentYTDDiscount);

float PrintTotalPurchaseBeforeDiscount(float sngTodaysTotalPurchases);

float PrintManagmentDiscountThisPurchase(float sngManagmentDiscountThisPurchase);

float PrintManagmentTotalWithDiscount(float sngManagmentTotalWithDiscount);

float  PrintHourlyDiscountPercentage(float sngHourlyDiscountPercentage);

float PrintHourlyYTDDiscount(float sngHourlyYTDDiscount);

float PrintHourlyDiscountThisPurchase(float sngHourlyDiscountThisPurchase);

float PrintHourlyTotalWithDiscount(float sngHourlyTotalWithDiscount);

char GetAnotherEmployee();

float AllEmployeeTotalBeforeDiscountOfTheDay(float sngTodaysTotalPurchases);

float AllEmployeeTotalAfterDiscount(float sngHourlyTotalWithDiscount, float sngManagmentTotalWithDiscount, char charEmployeeStatus);

float PrintAllEmployeeTotalBeforeDiscountOfTheDay(float sngAllEmployeeTotalBeforeDiscount);

float PrintAllEmployeeTotalAfterDiscount(float sngAllEmployeeTotalAfterDiscount);



// ------------------------------------------------------------------------------------------
// Name: main
// Abstract: This is where the program starts
// ------------------------------------------------------------------------------------------
void main()
{
	//character variables
	char charEmployeeStatus = ' ';
	char charAnotherEmployee = ' ';

	//integer variables
	int intYearsEmployed = 0;

	//float variables
	float sngPreviousPurchasesBeforeDiscount = 0.0;
	float sngTodaysTotalPurchases = 0.0;
	float sngManagmentDiscountPercentage = 0.0;
	float sngManagmentTotalWithDiscount = 0.0;
	float sngManagmentYTDDiscount = 0.0;
	float sngManagmentDiscountThisPurchase = 0.0;
	float sngHourlyDiscountPercentage = 0.0;
	float sngHourlyYTDDiscount = 0.0;
	float sngHourlyDiscountThisPurchase = 0.0;
	float sngHourlyTotalWithDiscount = 0.0;
	float sngAllEmployeeTotalBeforeDiscount = 0;
	float sngAllEmployeeTotalAfterDiscount = 0;

	//Gets the employee status 
	charEmployeeStatus = GetEmployeeStatus();

	//If the employee status == M for managment 
	if (charEmployeeStatus == 'M')
	{
		do 
		{
			
			//Gets how many years the employee has been employed 
			intYearsEmployed					=			GetYearsEmployed();

			//Gets the dollar amount of previous purchases the employee had 
			sngPreviousPurchasesBeforeDiscount	=			GetPreviousPurchasesBeforeDiscount();

			//Gets todays total purchases 
			sngTodaysTotalPurchases				=			GetTodaysTotalPurchases();


															printf("\n");

			sngManagmentDiscountPercentage		=			GetManagmentDiscountPercentage(intYearsEmployed);

			sngManagmentYTDDiscount				=			GetManagmentYearToDateDiscount(sngManagmentDiscountPercentage, sngPreviousPurchasesBeforeDiscount);

			sngManagmentDiscountThisPurchase	=			GetManagmentDiscountThisPurchase(sngTodaysTotalPurchases, sngManagmentDiscountPercentage);

			sngManagmentTotalWithDiscount		=			GetManagmentTotalWithDiscount(sngTodaysTotalPurchases, sngManagmentDiscountPercentage);

															PrintManagmentDiscountPercentage(sngManagmentDiscountPercentage);

															PrintManagmentYTDDiscount(sngManagmentYTDDiscount);

															PrintTotalPurchaseBeforeDiscount(sngTodaysTotalPurchases);

															PrintManagmentDiscountThisPurchase(sngManagmentDiscountThisPurchase);

															PrintManagmentTotalWithDiscount(sngManagmentTotalWithDiscount);

															printf("\n");

			charAnotherEmployee					=			GetAnotherEmployee();

			sngAllEmployeeTotalBeforeDiscount	=			AllEmployeeTotalBeforeDiscountOfTheDay(sngTodaysTotalPurchases);

			sngAllEmployeeTotalAfterDiscount	=			AllEmployeeTotalAfterDiscount(sngHourlyTotalWithDiscount, sngManagmentTotalWithDiscount, charEmployeeStatus);


		} while (charAnotherEmployee == 'Y');
		//is another employee == N then...
															PrintAllEmployeeTotalBeforeDiscountOfTheDay(sngAllEmployeeTotalBeforeDiscount);

															PrintAllEmployeeTotalAfterDiscount(sngAllEmployeeTotalAfterDiscount);
												
	}

	//if the employee status == H for hourly 
	if (charEmployeeStatus == 'H')

		do
		{
			//Gets how many years the employee has been employed 
			intYearsEmployed					=				GetYearsEmployed();

			//Gets the dollar amount of previous purchases the employee had 
			sngPreviousPurchasesBeforeDiscount	=				GetPreviousPurchasesBeforeDiscount();

			//Gets todays total purchases 
			sngTodaysTotalPurchases				=				GetTodaysTotalPurchases();

																printf("\n");

			sngHourlyDiscountPercentage			=				GetHourlyDiscountPercentage(intYearsEmployed);

			sngHourlyYTDDiscount				=				GetHourlyYearToDateDiscount(sngHourlyDiscountPercentage, sngPreviousPurchasesBeforeDiscount);

			sngHourlyDiscountThisPurchase		=				GetHourlyDiscountThisPurchase(sngTodaysTotalPurchases, sngHourlyDiscountPercentage);

			sngHourlyTotalWithDiscount			=				GetHourlyTotalWithDiscount(sngTodaysTotalPurchases, sngHourlyDiscountPercentage);

																PrintHourlyDiscountPercentage(sngHourlyDiscountPercentage);

																PrintHourlyYTDDiscount(sngHourlyYTDDiscount);

																PrintTotalPurchaseBeforeDiscount(sngTodaysTotalPurchases);

																PrintHourlyDiscountThisPurchase(sngHourlyDiscountThisPurchase);

																PrintHourlyTotalWithDiscount(sngHourlyTotalWithDiscount);

																printf("\n");

			charAnotherEmployee					=				GetAnotherEmployee();

			sngAllEmployeeTotalBeforeDiscount	=				AllEmployeeTotalBeforeDiscountOfTheDay(sngTodaysTotalPurchases);

			sngAllEmployeeTotalAfterDiscount	=				AllEmployeeTotalAfterDiscount(sngHourlyTotalWithDiscount, sngManagmentTotalWithDiscount, charEmployeeStatus);


		}	while (charAnotherEmployee == 'Y');
		//is another employee == N then...

																PrintAllEmployeeTotalBeforeDiscountOfTheDay(sngAllEmployeeTotalBeforeDiscount);

																PrintAllEmployeeTotalAfterDiscount(sngAllEmployeeTotalAfterDiscount);




}
// ------------------------------------------------------------------------------------------
// Name: GetYearsEmployed
// Abstract: Gets how long the employee has been employed 
// ------------------------------------------------------------------------------------------
int GetYearsEmployed()
{
	//years employed variable
	int intYearsEmployed = 0;

	//loops until the number of years employed is greater than 0
	do
	{
		printf("Please enter the number of years you have been employed:");
		scanf_s("%d", &intYearsEmployed);

	} while (intYearsEmployed <= 0);

	//returns the number of years employed 
	return intYearsEmployed;
}

// ------------------------------------------------------------------------------------------
// Name: GetPreviousPurchasesBeforeDiscount
// Abstract: Gets the dollar amount of previous purchases the employee had
// ------------------------------------------------------------------------------------------
float GetPreviousPurchasesBeforeDiscount()
{
	//previous purchases before discount variable
	float sngPreviousPurchasesBeforeDiscount = 0.0;

	//loops until previous purchases before discount is greater than 0
	do
	{
		printf("Please enter your previous purchases before discounts:");
		scanf_s("%f", &sngPreviousPurchasesBeforeDiscount);

	} while (sngPreviousPurchasesBeforeDiscount <= 0.0);

	//returns previous purchases before discount
	return sngPreviousPurchasesBeforeDiscount;
}

// ------------------------------------------------------------------------------------------
// Name: GetEmployeeStatus
// Abstract: Gets if the employee is a manager or an hourly employee
// ------------------------------------------------------------------------------------------
char GetEmployeeStatus()
{
	//employee status variable
	char charEmployeeStatus = ' ';
	
	//loops until the employee status has been entered and is a M for managment or H for hourly
	do
	{
		printf("Please enter a M if you are apart of managment or a H if you are an hourly employee:");
		scanf_s("%c", &charEmployeeStatus);

	} while (charEmployeeStatus != 'M' && charEmployeeStatus != 'H');

	//returns the employee status
	return charEmployeeStatus;
}

// ------------------------------------------------------------------------------------------
// Name: GetTodaysTotalPurchases
// Abstract: Gets todays total purchases
// ------------------------------------------------------------------------------------------
float GetTodaysTotalPurchases()
{
	//todays total purchases variable
	float sngTodaysTotalPurchases = 0.0;

	//loops until todays total purchases is greater than 0
	do
	{
		printf("Please enter todays total purchases:");
		scanf_s("%f", &sngTodaysTotalPurchases);

	} while (sngTodaysTotalPurchases <= 0);

	//returns todays total purchases
	return sngTodaysTotalPurchases;
}

// ------------------------------------------------------------------------------------------
// Name: GetManagmentDiscountPercentage
// Abstract: Gets the managment discount percentage based on the years of employment
// ------------------------------------------------------------------------------------------
float GetManagmentDiscountPercentage(int intYearsEmployed)
{
	//local varibale for discount percentage
	float sngManagmentDiscountPercentage = 0.0;

	//Gets the managment discount for years employed 
	//1-3 Years for 20%
	if (intYearsEmployed <= 3)
	{
		sngManagmentDiscountPercentage = .20;
	}
	//4-6 years for 24%
	else if (intYearsEmployed <= 6)
	{
		sngManagmentDiscountPercentage = .24;
	}
	//7-10 years for 30%
	else if (intYearsEmployed <= 10)
	{
		sngManagmentDiscountPercentage = .30;
	}
	//11-15 years for 35%
	else if (intYearsEmployed <= 15)
	{
		sngManagmentDiscountPercentage = .35;
	}
	//more than 15 years for 40%
	else if (intYearsEmployed > 15)
	{
		sngManagmentDiscountPercentage = .40;
	}

	//returns the managment discount based on years employed
	return sngManagmentDiscountPercentage;
}

// ------------------------------------------------------------------------------------------
// Name: GetHourlyDiscountPercentage
// Abstract: Gets the hourly discount percentage based on the years of employment
// ------------------------------------------------------------------------------------------
float GetHourlyDiscountPercentage(int intYearsEmployed)
{
	//local varibale for discount percentage
	float sngHourlyDiscountPercentage = 0.0;

	//Gets the managment discount for years employed 
	//1-3 Years for 10%
	if (intYearsEmployed <= 3)
	{
		sngHourlyDiscountPercentage = .10;
	}
	//4-6 years for 14%
	else if (intYearsEmployed <= 6)
	{
		sngHourlyDiscountPercentage = .14;
	}
	//7-10 years for 20%
	else if (intYearsEmployed <= 10)
	{
		sngHourlyDiscountPercentage = .20;
	}
	//11-15 years for 25%
	else if (intYearsEmployed <= 15)
	{
		sngHourlyDiscountPercentage = .25;
	}
	//more than 15 years for 30%
	else if (intYearsEmployed > 15)
	{
		sngHourlyDiscountPercentage = .30;
	}

	//returns the hourly discount based on years employed
	return sngHourlyDiscountPercentage;
}

// ------------------------------------------------------------------------------------------
// Name: GetManagmentYearToDateDiscount
// Abstract: Gets discount from the total purchase before today * discount
// ------------------------------------------------------------------------------------------
float GetManagmentYearToDateDiscount(float sngManagmentDiscountPercentage, float sngPreviousPurchasesBeforeDiscount)
{
	//local variable for YTD discount 
	float sngManagmentYTDDiscount = 0.0;

	//Calculation for the managment YTD discount 
	sngManagmentYTDDiscount = sngPreviousPurchasesBeforeDiscount * sngManagmentDiscountPercentage;

	//returns the managment YTD
	return sngManagmentYTDDiscount;

}

// ------------------------------------------------------------------------------------------
// Name: GetManagmentDiscountThisPurchase
// Abstract: Gets the managment discount this purchase if under $200
// ------------------------------------------------------------------------------------------
float GetManagmentDiscountThisPurchase(float sngTodaysTotalPurchases, float sngManagmentDiscountPercentage)
{
	//local variable for employee discount this purchase 
	float sngManagmentDiscountThisPurchase = 0.0;

	//Calculation for managment discount this purchase
	sngManagmentDiscountThisPurchase = sngTodaysTotalPurchases * sngManagmentDiscountPercentage;

	//Checks to see if the discount is less than or greater than the $200 discount limint
	if (sngManagmentDiscountThisPurchase < 200.0)
	{
		sngManagmentDiscountThisPurchase = sngManagmentDiscountThisPurchase;
	}

	else if (sngManagmentDiscountThisPurchase > 200.0)
	{
		sngManagmentDiscountThisPurchase = sngTodaysTotalPurchases;
	}

	//returns the employee discount this purchase
	return sngManagmentDiscountThisPurchase;

}

// ------------------------------------------------------------------------------------------
// Name: GetManagmentTotalWithDiscount
// Abstract: Gets managment total with discount
// ------------------------------------------------------------------------------------------
float GetManagmentTotalWithDiscount(float sngTodaysTotalPurchases, float sngManagmentDiscountPercentage)
{
	//local variable for total with discount 
	float sngManagmentTotalWithDiscount = 0.0;

	//Calculation for managment total with discount
	sngManagmentTotalWithDiscount = sngTodaysTotalPurchases - (sngTodaysTotalPurchases * sngManagmentDiscountPercentage);

	//returns the managment total with discount 
	return sngManagmentTotalWithDiscount;
}

// ------------------------------------------------------------------------------------------
// Name: GetHourlyYearToDateDiscount
// Abstract: Gets discount from the total purchase before today * discount
// ------------------------------------------------------------------------------------------
float GetHourlyYearToDateDiscount(float sngHourlyDiscountPercentage, float sngPreviousPurchasesBeforeDiscount)
{
	//local variable for YTD discount 
	float sngHourlyYTDDiscount = 0.0;

	//Calculation for the managment YTD discount 
	sngHourlyYTDDiscount = sngPreviousPurchasesBeforeDiscount * sngHourlyDiscountPercentage;

	//returns the managment YTD
	return sngHourlyYTDDiscount;

}

// ------------------------------------------------------------------------------------------
// Name: GetHourlyDiscountThisPurchase
// Abstract: Gets the hourly discount this purchase if under $200
// ------------------------------------------------------------------------------------------
float GetHourlyDiscountThisPurchase(float sngTodaysTotalPurchases, float sngHourlyDiscountPercentage)
{
	//local variable for employee discount this purchase 
	float sngHourlyDiscountThisPurchase = 0.0;

	//Calculation for managment discount this purchase
	sngHourlyDiscountThisPurchase = sngTodaysTotalPurchases * sngHourlyDiscountPercentage;

	//Checks to see if the discount is less than or greater than the $200 discount limint
	if (sngHourlyDiscountThisPurchase < 200.0)
	{
		sngHourlyDiscountThisPurchase = sngHourlyDiscountThisPurchase;
	}

	else if (sngHourlyDiscountThisPurchase > 200.0)
	{
		sngHourlyDiscountThisPurchase = sngTodaysTotalPurchases;
	}

	//returns the employee discount this purchase
	return sngHourlyDiscountThisPurchase;

}

// ------------------------------------------------------------------------------------------
// Name: GetHourlyTotalWithDiscount
// Abstract: Gets hourly total with discount
// ------------------------------------------------------------------------------------------
float GetHourlyTotalWithDiscount(float sngTodaysTotalPurchases, float sngHourlyDiscountPercentage)
{
	//local variable for total with discount 
	float sngHourlyTotalWithDiscount = 0.0;

	//Calculation for managment total with discount
	sngHourlyTotalWithDiscount = sngTodaysTotalPurchases - (sngTodaysTotalPurchases * sngHourlyDiscountPercentage);

	//returns the managment total with discount 
	return sngHourlyTotalWithDiscount;
}

// ------------------------------------------------------------------------------------------
// Name: PrintManagmentTotalWithDiscount
// Abstract: prints the managment total with discount
// ------------------------------------------------------------------------------------------
float PrintManagmentTotalWithDiscount(float sngManagmentTotalWithDiscount)
{
	//prints the managment total with discount
	printf_s("Total with discount is $ %.2f\n", sngManagmentTotalWithDiscount);
}

// ------------------------------------------------------------------------------------------
// Name: PrintManagmentDiscountPercentage
// Abstract: prints the managment discount percentage
// ------------------------------------------------------------------------------------------
float PrintManagmentDiscountPercentage(float sngManagmentDiscountPercentage)
{
	//Converts the floating number to a percentage by multiplying by 100
	sngManagmentDiscountPercentage = sngManagmentDiscountPercentage * 100;

	//prints the employee discount percentage
	printf_s("Employee discount percentage is %.2f %%\n", sngManagmentDiscountPercentage);
}

// ------------------------------------------------------------------------------------------
// Name: PrintManagmentYTDDiscount
// Abstract: prints the managment YTD discount
// ------------------------------------------------------------------------------------------
float PrintManagmentYTDDiscount(float sngManagmentYTDDiscount)
{
	//prints the managment YTD discount 
	printf_s("Total year to date discount is $ %.2f\n", sngManagmentYTDDiscount);
}

// ------------------------------------------------------------------------------------------
// Name: PrintTotalPurchaseBeforeDiscount
// Abstract: prints the total with discount
// ------------------------------------------------------------------------------------------
float PrintTotalPurchaseBeforeDiscount(float sngTodaysTotalPurchases)
{
	//prints the total purchase of today before discount
	printf_s("Total purchase today before discount is $ %.2f\n", sngTodaysTotalPurchases);
}

// ------------------------------------------------------------------------------------------
// Name: PrintManagmentTotalWithDiscount
// Abstract: prints the managment total with discount
// ------------------------------------------------------------------------------------------
float PrintManagmentDiscountThisPurchase(float sngManagmentDiscountThisPurchase)
{
	//prints the managment total with discount
	printf_s("Total discount this purchase is $ %.2f\n", sngManagmentDiscountThisPurchase);

}

// ------------------------------------------------------------------------------------------
// Name: PrintHourlyDiscountPercentage
// Abstract: prints the hourly discount percentage
// ------------------------------------------------------------------------------------------
float PrintHourlyDiscountPercentage(float sngHourlyDiscountPercentage)
{
	//Converts the floating number to a percentage by multiplying by 100
	sngHourlyDiscountPercentage = sngHourlyDiscountPercentage * 100;

	//prints the employee discount percentage
	printf_s("Employee discount percentage is %.2f %%\n", sngHourlyDiscountPercentage);
}

// ------------------------------------------------------------------------------------------
// Name: PrintHourlyYTDDiscount
// Abstract: prints the hourly YTD discount
// ------------------------------------------------------------------------------------------
float PrintHourlyYTDDiscount(float sngHourlyYTDDiscount)
{
	//prints the managment YTD discount 
	printf_s("Total year to date discount is $ %.2f\n", sngHourlyYTDDiscount);
}

// ------------------------------------------------------------------------------------------
// Name: PrintHourlyDiscountThisPurchase
// Abstract: prints the hourly total with discount
// ------------------------------------------------------------------------------------------
float PrintHourlyDiscountThisPurchase(float sngHourlyDiscountThisPurchase)
{
	//prints the managment total with discount
	printf_s("Total discount this purchase is $ %.2f\n", sngHourlyDiscountThisPurchase);

}

// ------------------------------------------------------------------------------------------
// Name: PrintHourlyTotalWithDiscount
// Abstract: prints the hourly total with discount
// ------------------------------------------------------------------------------------------
float PrintHourlyTotalWithDiscount(float sngHourlyTotalWithDiscount)
{
	//prints the managment total with discount
	printf_s("Total with discount is $ %.2f\n", sngHourlyTotalWithDiscount);
}

// ------------------------------------------------------------------------------------------
// Name:GetAnotherEmployee
// Abstract: Gets if there is another employee
// ------------------------------------------------------------------------------------------
char GetAnotherEmployee()
{
	//Variable for another employee 
	char charAnotherEmployee = ' ';

	do
	{
		printf("Is there another employee? Enter Y for Yes and N for No:");
		scanf_s("%c", &charAnotherEmployee);


	} while (charAnotherEmployee != 'Y' && charAnotherEmployee != 'N');

	//Returns another employee
	return charAnotherEmployee;
}	

// ------------------------------------------------------------------------------------------
// Name:AllEmployeeTotalBeforeDiscountOfTheDay
// Abstract: Gets the total from the discount of the day from all employees
// ------------------------------------------------------------------------------------------
float AllEmployeeTotalBeforeDiscountOfTheDay(float sngTodaysTotalPurchases)
{
	//variable for the function 
	float sngAllEmployeeTotalBeforeDiscount = 0;

	//Gets the total from the discount of the day from all employees
	sngAllEmployeeTotalBeforeDiscount = sngTodaysTotalPurchases += sngTodaysTotalPurchases;

	//returns the total 
	sngAllEmployeeTotalBeforeDiscount;
}

// ------------------------------------------------------------------------------------------
// Name:AllEmployeeTotalAfterDiscount
// Abstract: Gets all employee total after discount
// ------------------------------------------------------------------------------------------
float AllEmployeeTotalAfterDiscount(float sngHourlyTotalWithDiscount, float sngManagmentTotalWithDiscount, char charEmployeeStatus)
{
	//Variable for this function 
	float sngAllEmployeeTotalAfterDiscount = 0;

	if (charEmployeeStatus == 'H')
	{
		sngAllEmployeeTotalAfterDiscount = sngHourlyTotalWithDiscount += sngHourlyTotalWithDiscount;
	}

	else if (charEmployeeStatus == 'M')
	{
		sngAllEmployeeTotalAfterDiscount = sngManagmentTotalWithDiscount += sngManagmentTotalWithDiscount;
	}

	//returns the total 
	return sngAllEmployeeTotalAfterDiscount;

}

// ------------------------------------------------------------------------------------------
// Name:PrintAllEmployeeTotalBeforeDiscountOfTheDay
// Abstract: prints PrintAllEmployeeTotalBeforeDiscountOfTheDay
// ------------------------------------------------------------------------------------------
float PrintAllEmployeeTotalBeforeDiscountOfTheDay(float sngAllEmployeeTotalBeforeDiscount)
{
	//prints the total of all employees before discount
	printf_s("Total of all employees before discount is $ %.2f\n", sngAllEmployeeTotalBeforeDiscount);
}

// ------------------------------------------------------------------------------------------
// Name:PrintAllEmployeeTotalAfterDiscount
// Abstract: prints PrintAllEmployeeTotalAfterDiscount
// ------------------------------------------------------------------------------------------
float PrintAllEmployeeTotalAfterDiscount(float sngAllEmployeeTotalAfterDiscount)
{
	//prints the total of all employees before discount
	printf_s("Total of all employees after discount is $ %.2f\n", sngAllEmployeeTotalAfterDiscount);
}